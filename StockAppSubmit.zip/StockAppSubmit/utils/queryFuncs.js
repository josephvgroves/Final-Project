const dataProcessing = require("./dataProcessing");

/** SETUP */
const stockDataKEY = "vR9673IkmM1jBpq6teMSAsHaLYP9EjjhUMq5S3cI"; // my api key
//const dataProcessing = require('dataProcessing.js');


/** queries the data on the S&P500 stock name, really just stock price at given date */
async function querySPTraining(tickers, startDate, fs, path){
    for(var i = 0; i < tickers.length; i++){

        await fetch("https://api.stockdata.org/v1/data/eod?symbols="+tickers[i] + "&api_token="+stockDataKEY +"&date_from="+startDate)
            .then(response => response.json())
                .then(data => {
                    dataProcessing.appendStockData(fs, path, data, tickers[i]);
                })
                .catch(error => {
                    console.error('Error fetching stock data in querySPTraining():', error);
                });
    }
}

/** queries the full! data on the S&P500 stock name */
async function queryFullSPTraining(tickers, startDate, fs, path){
    for(var i = 0; i < tickers.length; i++){

        await fetch("https://api.stockdata.org/v1/data/eod?symbols="+tickers[i] + "&api_token="+stockDataKEY +"&date_from="+startDate)
            .then(response => response.json())
                .then(data => {
                    dataProcessing.appendFullStockData(fs, path, data, tickers[i]);
                })
                .catch(error => {
                    console.error('Error fetching stock data in queryFullSPTraining():', error);
                });
    }
}


module.exports = {querySPTraining:querySPTraining, queryFullSPTraining:queryFullSPTraining };