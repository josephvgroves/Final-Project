// dataProcessing.js has functions for reading and writing the stock data to files

/*************DATA COLLECTION FUNCTIONS *********************************************************/
/** get stock symobls from designated csv file, with a header as the first line and the symbol as the first entry on each subsequent line */
function getTickerSymbols(fs, path){
    // array to return
    tickers = [];

    // read the file by line
    const reader = fs.readFileSync(path, 'utf8').split('\n');
    
    // extract first entry after first line for all subsequent lines
    for(var i = 1; i < reader.length; i++){
        tickers.push(reader[i].split(',')[0]);
    }
            
    // send it on back
    return tickers;
}

/** takes the response to a stock query and writes it as a line in the datafile sent 
 * THIS VERSION ONLY LOGS THE STOCK PRICES AND DATES
*/
function appendStockData(fs,path,data,ticker){
    if(fs.existsSync(path)){
        const writer = fs.createWriteStream(path, { flags: 'a' }); // 'a' for append mode
    
        // string for each line
        var output = ticker + ',';
        
        // iterate over each item in stockNames, creating a row for each
        for(var k = 0; k < data.data.length; k++){

            output+=data.data[k].close + ',';
        
        }
        output = output.slice(0,-1);
        output += '\n';
        writer.write(output);
        writer.close();
    }
    else{

        const writer = fs.createWriteStream(path, { flags: 'a' }); // 'a' for append mode
    
        var dateString = "Dates,";
        // write the dates at the top of the file
        for(var j = 0; j < data.data.length; j++){
            dateString += data.data[j].date.slice(0,10) + ',';
        }
        dateString = dateString.slice(0,-1);
        dateString += '\n';
        writer.write(dateString);

        // string for each line
        var output = ticker + ',';
        
        // iterate over each item in stockNames, creating a row for each
        for(var k = 0; k < data.data.length; k++){

            output+=data.data[k].close + ',';
        
        }
        output = output.slice(0,-1);
        output += '\n';
        writer.write(output);
        writer.close();
    }
} 

/** takes the response to a stock query and writes all data it as a line in the datafile sent 
 * THIS FUNCTION TAKES ALL THE HISTORICAL DATA
 * The CSV File for each day is in the order of close, open, high, low, volume
*
 * 
*/
function appendFullStockData(fs,path,data,ticker){
    if(fs.existsSync(path)){
        const writer = fs.createWriteStream(path, { flags: 'a' }); // 'a' for append mode
    
        // string for each line
        var output = ticker + ',';
        
        // iterate over each item in stockNames, creating a row for each
        for(var k = 0; k < data.data.length; k++){
            output+=data.data[k].close + ',' + data.data[k].open + ',' + data.data[k].high + ',' + 
                data.data[k].low + ',' + data.data[k].volume + ',';
        }
        output = output.slice(0,-1);
        output += '\n';
        writer.write(output);
        writer.close();
    }
    else{

        const writer = fs.createWriteStream(path, { flags: 'a' }); // 'a' for append mode
    
        var dateString = "Dates,";
        // write the dates at the top of the file, 5 fields since there are 5 data points for each day
        for(var j = 0; j < data.data.length; j++){
            dateString += data.data[j].date.slice(0,10) + " close,";
            dateString += data.data[j].date.slice(0,10) + " open,";
            dateString += data.data[j].date.slice(0,10) + "high,";
            dateString += data.data[j].date.slice(0,10) + "low,";
            dateString += data.data[j].date.slice(0,10) + "volume,";
        }
        dateString = dateString.slice(0,-1);
        dateString += '\n';
        writer.write(dateString);

        // string for each line
        var output = ticker + ',';
        
        // iterate over each item in stockNames, creating a row for each
        for(var k = 0; k < data.data.length; k++){

            output+=data.data[k].close + ',' + data.data[k].open + ',' + data.data[k].high + ',' + 
                data.data[k].low + ',' + data.data[k].volume + ',';
        
        }
        output = output.slice(0,-1);
        output += '\n';
        writer.write(output);
        writer.close();
    }
} 

/** merges the training and target data files into a single csv file, necessary because historical queries
 * have 180 day max length
 */
function mergeData(fs, trainPath, targetPath){
     // get the files in the training data directory
    const trainLines = fs.readFileSync("training_data\\" + trainPath, 'utf8').split('\n');
    const targetLines = fs.readFileSync("training_data\\" + targetPath, 'utf8').split('\n');

    // name of the file and fs writer object
    var fileName = "mergedSP500.csv";  
    const writer = fs.createWriteStream(fileName, { flags: 'a' }); // 'a' for append mode
    
    //iterate over the stocks from the training data
    for(var i = 0; i < trainLines.length; i++){
        var splitLine = trainLines[i].split(',');
        if(splitLine.length == 126) // the data period selected should have 126 entries including the stock ticker
        {
            // the target data period should have 123 entries
            for(var j = 0; j < targetLines.length; j++){
                var splitTarg = targetLines[j].split(',');
                
                // matching stock symbols
                if(splitTarg[0] == splitLine[0]){
                    if(splitTarg.length == 123){
                        var output = targetLines[j] + ',';
                        for(var k = 1; k < splitLine.length; k++){
                            output += splitLine[k] + ',';
                        }
                        writer.write(output + '\n');
                    }
                    else{
                        console.log("Target data incomplete for " + splitLine[0] + ":" + splitTarg[0]);
                        console.log(targetLines[j]);
                    }
                    break; //match found, no need to continue loop
                }
            }
        }
        else{
            console.log("Stock " + splitLine[0] + " does not have a full dataset. Line displayed below:");
            console.log(trainLines[i]);
        }
    }
}

/** merges the full sets of historical stock data */
function mergeFullData(fs, trainPath, targetPath){
     // get the files in the training data directory
    const trainLines = fs.readFileSync("training_data\\" + trainPath, 'utf8').split('\n');
    const targetLines = fs.readFileSync("training_data\\" + targetPath, 'utf8').split('\n');

    // name of the file and fs writer object
    var fileName = "mergedFullSP500.csv";  
    const writer = fs.createWriteStream(fileName, { flags: 'a' }); // 'a' for append mode
    
    //iterate over the stocks from the training data
    for(var i = 0; i < trainLines.length; i++){
        var splitLine = trainLines[i].split(',');
        if(splitLine.length == 626) // the data period selected should have 126 days with 630 entries including the stock ticker
        {
            // the target data period should have 123 days, 615 entries
            for(var j = 0; j < targetLines.length; j++){
                var splitTarg = targetLines[j].split(',');
                
                // matching stock symbols
                if(splitTarg[0] == splitLine[0]){
                    if(splitTarg.length == 611){
                        var output = targetLines[j] + ',';
                        for(var k = 1; k < splitLine.length; k++){
                            output += splitLine[k] + ',';
                        }
                        writer.write(output + '\n');
                    }
                    else{
                        console.log("Target data incomplete for " + splitLine[0] + ":" + splitTarg[0]);
                        console.log(targetLines[j]);
                    }
                    break; //match found, no need to continue loop
                }
            }
        }
        else{
            console.log("Stock " + splitLine[0] + " does not have a full dataset. Line displayed below:");
            console.log(trainLines[i]);
        }
    }
}

/** a useless function to test module importing after some environment issues on different computers */
function dunsail(){
    console.log("Greetings Captain");
}

/****************************************USER FUNCTIONS ******************************************/
/** formats the current Date obtained by javascript into the correct format for queries and suggests a starting query
 * date 6 months in the past ignoring leap years
 */
function getSuggestedDate(currentDate){
    current = "";
    suggestedDate = "";
    current += currentDate.getFullYear() + '-';
    
    // Format the current date
    // because they're 0-indexed
    month = currentDate.getMonth()+1;
    if(month <= 9)
        current += '0' + month.toString() + '-';
    else
        current += month.toString() + '-';

    day = currentDate.getDate();
    if(day < 10)
        current += '0' + day.toString();
    else
        current += day.toString();

    // calculate the suggested date, roughly 6 months before current date
    if(month <= 6)
        suggestedDate = (currentDate.getFullYear() -1).toString() + '-';
    else
        suggestedDate = currentDate.getFullYear().toString() + '-';
    
    newMonth = month - 6;
    if(newMonth <= 0)
        newMonth += 12;

    if(newMonth < 10)
        suggestedDate += '0' + newMonth.toString() + '-';
    else
        suggestedDate += newMonth.toString() + '-';

    if(day >= 29 && newMonth ==2)
        day = 28; // just go to the last day of February
    if(day >= 31 && (newMonth == 4 || newMonth == 6 || newMonth == 9 || newMonth == 11))
        day = 30

    if(day < 10)
        suggestedDate += '0' + day.toString();
    else
        suggestedDate += day.toString();

    return suggestedDate;
}

/** writes JSON file to a CSV using a historical quote from the stockdata.org api */
function stockdataJSONToCSV(stock_data, stockName,fs){
   
    // the names for the data from the stockdata.org query
    const keys = ["date","close","open","high","low","volume"];
    // name of the file
    var fileName = stockName + stock_data.meta.date_from + "_" + stock_data.meta.date_to + ".csv"
    // file contents
    var outputFile = "";

    // write the keys in the first row
    for(var k = 0; k < keys.length; k++){
        outputFile += keys[k] + ',';
    }
    outputFile = outputFile.slice(0,outputFile.length-1);
    outputFile+= '\n';

    for(var d = 0; d < stock_data.data.length; d++){
        outputFile += stock_data.data[d].date + ',';
        outputFile += stock_data.data[d].close + ',';
        outputFile += stock_data.data[d].open + ',';
        outputFile += stock_data.data[d].high + ',';
        outputFile += stock_data.data[d].low + ',';
        outputFile += stock_data.data[d].volume + '\n';
    }

    fs.writeFile("public\\user_queries\\" + fileName, outputFile, (err) => {
    // In case of a error throw err.
    if (err) throw err;
    });
}

module.exports = {getTickerSymbols:getTickerSymbols, appendStockData:appendStockData, mergeData:mergeData,
    appendFullStockData:appendFullStockData, mergeFullData:mergeFullData, dunsail:dunsail,
    stockdataJSONToCSV:stockdataJSONToCSV, getSuggestedDate:getSuggestedDate};
