const path = require("path");
const { pathToFileURL } = require("url");

async function loadModel(modelPath, tf) {
 /* console.log("Loading Model");

  // Resolve to an absolute path
  const absPath = path.resolve(modelPath);

  // Convert to file:// URL
  const modelUrl = pathToFileURL(absPath).href;

  const model = await tf.loadLayersModel(modelUrl);

  console.log("Model Loaded");
  return model;*/
}

module.exports = { loadModel };
