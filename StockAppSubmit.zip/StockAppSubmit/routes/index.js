// stockdata.org api key: vR9673IkmM1jBpq6teMSAsHaLYP9EjjhUMq5S3cI
// polygon.io api key: EUJuhWTspIi4p2_Jsb2tiCI9Jw3wV1Qq

/** DEPENDENCIES AND MODULES */
var express = require("express");
var router = express.Router();
const stockDataKEY = "vR9673IkmM1jBpq6teMSAsHaLYP9EjjhUMq5S3cI";
const stockDataFreeKEY = "vR9673IkmM1jBpq6teMSAsHaLYP9EjjhUMq5S3cI";
const polygonKEY = "EUJuhWTspIi4p2_Jsb2tiCI9Jw3wV1Qq";
const dataProcessing = require('../utils/dataProcessing.js');
const queryFuncs = require('../utils/queryFuncs.js');
const modelFuncs = require('../utils/modelFuncs.js')
const fs = require('fs');
//const tf = require('@tensorflow/tfjs-node');
const path = require('path');
const { pathToFileURL } = require("url");

// for reasons I don't quite understand I have to import the fs library here and pass it to my helper function
// instead of importing it within the module?

/** DATA COLLECTION VARIABLES */
const startDate = "2023-06-17";  // the data start date for training data
const startTargetDate = "2023-12-15";
 

/** Default rendering of home directory */
router.get('/',(req,res)=>
{
     // update the date
    currentDate = new Date();
    // get reformatted and suggested query dates
    suggestedDate = dataProcessing.getSuggestedDate(currentDate);

    
    var dataFiles = fs.readdirSync("public\\user_queries\\");
    //console.log("Available Data Files: " + dataFiles);
    var models = fs.readdirSync("public\\models\\");
    //console.log("Available models: " + models)

    // default non-values when the user hasn't made a query yet
    stockName = "?"
    stockPrice = "0?"

    // pass along those values to render the page
    res.render('index',{displayMode:"height: 0; overflow: hidden;",dataFiles:dataFiles, models:models, currentDate:currentDate,suggestedDate:suggestedDate, stock_query_name:stockName,stock_query_price:stockPrice,stock_query_date:"",stockData:"",stock_vals:"",stock_dates:"",feedback:""});
});

//*************************USER VIEW PATHS***************************************************** */
/** called when the user inputs a ticker symbol, makes a query to StockData.org and displays basic CURRENT information */
router.post('/query', function(req, res){
    console.log("1");
    // update the date
    currentDate = new Date();
    // get reformatted and suggested query dates
    suggestedDate = dataProcessing.getSuggestedDate(currentDate);
    
    var dataFiles = fs.readdirSync("public\\user_queries\\");
    console.log("Available Data Files: " + dataFiles);
    var models = fs.readdirSync("public\\models\\");
    console.log("Available models: " + models)

    stockName = req.body.stockname;
    dateFrom = req.body.startdate;
    console.log("A");
    // check that the ticker symbol is valid
    // I initially had more stringent constraints but the Stock Tickers were more varied than expected
    if(stockName.length <= 8 ){  ///^[a-zA-Z]+$/.test(stockName) && 
        stockName = stockName.toUpperCase();

        fetch("https://api.stockdata.org/v1/data/eod?symbols="+stockName + "&api_token="+stockDataKEY +"&date_from="+dateFrom) 
            .then(response => response.json())
                .then(data => {
                    dataProcessing.stockdataJSONToCSV(data, stockName, fs);
                    console.log(data);
                    stockPrice = data.data[0].close;
                    lastDate = data.data[0].date;
                    
                    stockVals = [];
                    stockDates = [];
                    stockIndices = [];
                    for(var i = data.data.length -1; i >=0; i--)
                    {
                        stockVals.push(parseFloat(data.data[i].close))
                        stockDates.push(data.data[i].date.slice(0,10))
                        stockIndices.push(data.data.length -1 - i);
                    }
                    const stockData = {sv:stockVals,sd:stockDates};
                    res.render('index',{displayMode:"", dataFiles:dataFiles, models:models, currentDate:currentDate, suggestedDate:suggestedDate,stock_query_name:stockName,stock_query_price:stockPrice,feedback:"",stock_query_date:lastDate, stockData:stockData, stock_vals:stockVals, stock_dates:stockDates});
                })
                .catch(error => { 
                    console.error('Error fetching stock data in /query:', error);
                });
    }
    else{ // other characters are in the string, invalid input
        
        res.render('index',{displayMode:"none",stock_query_name:"",stock_query_price:"",stock_query_date:"",stock_vals:"",stock_dates:"",stockData:"",feedback:"Invalid Ticker Symbol: Must Be 4 Letters or Fewer, No Other Characters"});
    }
});

/** runs model on selected data */
router.post("/runModel", async (req, res) => {
 
});

//*************************DATA COLLECTION PATHS ************************************************/
/** collects data on S&P500 stocks and output dataset */
router.post('/querySP500', function(req, res){
   tickers = dataProcessing.getTickerSymbols(fs,"SP500.csv");
   
   // async function to get training data
   queryFuncs.querySPTraining(tickers, startDate, fs, "training_data//SPTrain.csv");
   queryFuncs.querySPTraining(tickers, startTargetDate, fs, "training_data//SPTarget.csv");     
});

/** merges the training and test files to create a continuous dataset of more than the original 180 days */
router.post('/mergeTrainTarget', function(req,res){
    trainPath = "SPTrain1.csv";
    targetPath = "SPTarget1.csv";  // manually changed the file names because sometimes the program would 
    dataProcessing.mergeData(fs,trainPath, targetPath);
});


/** collects all the historical data on S&P500 stocks and output dataset */
router.post('/queryFullSP500', function(req, res){
   tickers = dataProcessing.getTickerSymbols(fs,"SP500.csv");
   
   // async function to get training data
   queryFuncs.queryFullSPTraining(tickers, startDate, fs, "training_data//SPFullTrain.csv");
   queryFuncs.queryFullSPTraining(tickers, startTargetDate, fs, "training_data//SPFullTarget.csv");     
});

/** merges the full training and test files to create a continuous dataset of more than the original 180 days */
router.post('/queryMergeFullSP500', function(req,res){
    trainPath = "SPFullTrain.csv";
    targetPath = "SPFullTarget.csv";  // manually changed the file names because sometimes the program would 
    dataProcessing.mergeFullData(fs,trainPath, targetPath);
});



module.exports = router;


/*
  stockName = req.body.stockname;
        dateFrom = req.body.startdate;
        // check that the ticker symbol is valid
        if(stockName.length <= 8 ){  ///^[a-zA-Z]+$/.test(stockName) && 
            stockName = stockName.toUpperCase();

            fetch("https://api.stockdata.org/v1/data/eod?symbols="+stockName + "&api_token="+stockDataKEY +"&date_from="+dateFrom) 
                .then(response => response.json())
                    .then(data => {
                        dataProcessing.stockdataJSONToCSV(data, stockName, fs);
                        
                        stockPrice = data.data[0].close;
                        lastDate = data.data[0].date;
                       
                        stockVals = [];
                        stockDates = [];
                        stockIndices = [];
                        for(var i = data.data.length -1; i >=0; i--)
                        {
                            stockVals.push(parseFloat(data.data[i].close))
                            stockDates.push(data.data[i].date.slice(0,10))
                            stockIndices.push(data.data.length -1 - i);
                        }
                        //stock_data = {stockDates, stockVals}
                        //console.log(stockVals);
                        //console.log(stockDates);
                        //console.log(stockIndices);
                        const stockData = {sv:stockVals,sd:stockDates};
                        res.render('index',{stock_query_name:stockName,stock_query_price:stockPrice,feedback:"",stock_query_date:lastDate, stockData:stockData, stock_vals:stockVals, stock_dates:stockDates});
                        
                    })
                    .catch(error => {
                        
                        console.error('Error fetching stock data:', error);
                    });

        }
        else{ // other characters are in the string, invalid input
            
            res.render('index',{stock_query_name:"",stock_query_price:"",stock_query_date:"",stock_vals:"",stock_dates:"",stockData:"",feedback:"Invalid Ticker Symbol: Must Be 4 Letters or Fewer, No Other Characters"});
        }
*/
/** makes individual queries at a particular date and appends them to relevant file */

/*function queryDate(sn, dateTo){
    fetch("https://api.stockdata.org/v1/data/eod?symbols="+sn + "&api_token="+stockDataKEY +"&date_from="+dateTo +"&date_to="+dateTo) // + "&key_by_ticker=true") 
                .then(response => response.json())
                    .then((data) => {
                        dataProcessing.appendPrice(fs, sn,data,dateTo);
                        //console.log(sn)
                        //console.log(data);
                })
                .catch(error => {
                    
                    console.error('Error fetching stock data:', error);
                });
}

*/
/** called when the user inputs a ticker symbol */
/*router.post('/price_query', function(req, res){

    var dateFrom = "2023-12-15";
    var dateTo = "2023-12-15";
    
    // get the stock names all as one set
    stockCombo = "";
    for(var i = 0; i < stockNames.length; i++){
        stockCombo += stockNames[i] + ',';
    }
    /*stockCombo = stockCombo.slice(0,-1);
    //console.log("Testing String");
    //console.log(stockCombo);
    // attempt separate queries
    console.log("First is " + stockNames[1]);
    for(var j = 151; (j < 201 && j < stockNames.length); j++){
        queryDate(stockNames[j],dateTo);
    }
    
});
*/
/** combines the training-data files into a single file with ticker symbol followed by all of the data on a single long line */
/*router.post('/data_collate', function(req, res){
        dataProcessing.collateData(fs);
});
*/


/*
function stockdataJSONToCSV(stock_data, stockName,fs){
   
    // the names for the data from the stockdata.org query
    const keys = ["date","open","high","low","close","volume"];
    // name of the file
    var fileName = stockName + stock_data.meta.date_from + stock_data.meta.date_to + ".csv"
    // file contents
    var outputFile = "";

    // write the keys in the first row
    for(var k = 0; k < keys.length; k++){
        outputFile += keys[k] + ',';
    }
    outputFile = outputFile.slice(0,outputFile.length-1);
    outputFile+= '\n';

    for(var d = 0; d < stock_data.data.length; d++){
        outputFile += stock_data.data[d].date + ',';
        outputFile += stock_data.data[d].open + ',';
        outputFile += stock_data.data[d].high + ',';
        outputFile += stock_data.data[d].low + ',';
        outputFile += stock_data.data[d].close + ',';
        outputFile += stock_data.data[d].volume + '\n';
    }

    fs.writeFile("training_data\\" + fileName, outputFile, (err) => {
    // In case of a error throw err.
    if (err) throw err;
    });
}*/


   /*  PREVIOUS TEST API CALLS 
   //fetch('https://api.stockdata.org/v1/data/quote?symbols=INTC&api_token=' + stockDataKEY)
   // fetch("https://api.stockdata.org/v1/data/quote?symbols=TSLA&api_token="+stockDataKEY)// HTTP/1.1")
   fetch("https://api.stockdata.org/v1/data/eod?symbols="+stockName + "&api_token="+stockDataKEY) 
   .then(response => response.json())
    .then(data => {
        // Process the stock data (e.g., display stock prices)
        //console.log(data);
        dataProcessing.stockdataJSONToCSV(data, stockName, fs);
    })
    .catch(error => {
        console.error('Error fetching stock data:', error);
    });*/

    
// POLYGON CODE
 /*

     rest.stocks.lastQuote("INTC").then((data) => {
        console.log(data.ticker)
        //stockName=data.tickerc
        res.render('index',{stock_query_name:stockName,stock_query_price:"34"});
    })
    .catch((e) => {
        console.error("An error happened:", e)
        res.render('index',{stock_query_name:"Query Failed",stock_query_price:"No Value Retrieved"});
    })
    */

//import { jsonToCSV } from "../dataProcessing.js";
/* Polygon Code
const { restClient } = require("@polygon.io/client-js")
const rest = restClient("EUJuhWTspIi4p2_Jsb2tiCI9Jw3wV1Qq")
*/
